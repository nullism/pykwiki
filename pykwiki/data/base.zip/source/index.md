[[
title: Welcome
author: PyKwiki
description: The default PyKwiki startup page.
tags: [pykwiki]
]]

# Welcome!

Thanks for installing PyKwiki!

This page can be found in `source/index.md`.

Where to go from here:

* [Official Documentation](http://pykwiki.nullism.com/)
* [PyKwiki - Authoring](http://pykwiki.nullism.com/authoring.html)
* [PyKwiki - config.yaml](http://pykwiki.nullism.com/config.yaml.html)
* [PyKwiki - links.yaml](http://pykwiki.nullism.com/links.yaml.html)

Report issues at [GitHub - PyKwiki](https://github.com/webgovernor/pykwiki)


